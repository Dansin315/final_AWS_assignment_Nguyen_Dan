# AWS Cards Market WordPress Theme

A lightweight trading-card marketplace theme for a WordPress web service running on AWS EC2, ALB, Auto Scaling Group, and RDS.

This is a class-project prototype. It is **not** a real ecommerce/payment/escrow system.

## Features

- Marketplace-style homepage
- Card catalog custom post type
- Game, expansion, and rarity taxonomies
- Search and filter page at `/cards/`
- Card detail page with seller offer table
- Browser-side demo cart using `localStorage`
- Browser-side wants list using `localStorage`
- Demo data seeder under `Appearance > AWS Cards Demo`

## Local WordPress installation

1. Zip the folder as `aws-cards-market.zip`.
2. In WordPress Admin, go to `Appearance > Themes > Add New > Upload Theme`.
3. Upload and activate the theme.
4. Go to `Appearance > AWS Cards Demo` and click `Create Demo Cards`.
5. Go to `Settings > Permalinks` and click `Save Changes`.
6. Open `/cards/` to view the catalog.

## HA installation warning

If WordPress runs behind an ALB with two EC2 instances, uploading the theme through WordPress Admin may upload it to only one EC2 instance. For the AWS high-availability project, place this theme folder in your repository and copy it into `/var/www/html/wp-content/themes/aws-cards-market` from your EC2 `user-data.sh` script so every new ASG instance gets the same theme files.

## Permanent AWS implementation idea

Put this theme folder in your project under:

```text
themes/aws-cards-market
```

Then modify your EC2 user-data script to copy the theme into WordPress:

```bash
mkdir -p /var/www/html/wp-content/themes
cp -R /home/ec2-user/aws-cards-market /var/www/html/wp-content/themes/aws-cards-market
chown -R apache:apache /var/www/html/wp-content/themes/aws-cards-market
```

If you store the theme zip in S3, the user-data script can download and unzip it instead.
