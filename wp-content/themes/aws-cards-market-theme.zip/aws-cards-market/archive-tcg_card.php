<?php
/**
 * Card archive template.
 */
get_header();
$selected_game   = isset( $_GET['game'] ) ? sanitize_title( wp_unslash( $_GET['game'] ) ) : '';
$selected_set    = isset( $_GET['set'] ) ? sanitize_title( wp_unslash( $_GET['set'] ) ) : '';
$selected_rarity = isset( $_GET['rarity'] ) ? sanitize_title( wp_unslash( $_GET['rarity'] ) ) : '';
$selected_sort   = isset( $_GET['sort'] ) ? sanitize_key( wp_unslash( $_GET['sort'] ) ) : '';
$card_search     = isset( $_GET['card_search'] ) ? sanitize_text_field( wp_unslash( $_GET['card_search'] ) ) : '';
?>
<section class="aws-section">
    <div class="aws-wrap">
        <div class="aws-section-heading">
            <div>
                <h1 class="aws-page-title"><?php esc_html_e( 'Card Catalog', 'aws-cards-market' ); ?></h1>
                <p><?php esc_html_e( 'Search and filter demo trading-card listings by game, expansion, rarity, and price.', 'aws-cards-market' ); ?></p>
            </div>
        </div>

        <div class="aws-market-layout">
            <aside class="aws-filter-card">
                <h2><?php esc_html_e( 'Search filters', 'aws-cards-market' ); ?></h2>
                <form class="aws-filter-grid" method="get" action="<?php echo esc_url( awscards_archive_url() ); ?>">
                    <label><?php esc_html_e( 'Card name', 'aws-cards-market' ); ?>
                        <input class="aws-input" type="search" name="card_search" value="<?php echo esc_attr( $card_search ); ?>" placeholder="<?php esc_attr_e( 'e.g. Dragon', 'aws-cards-market' ); ?>">
                    </label>
                    <label><?php esc_html_e( 'Game', 'aws-cards-market' ); ?>
                        <?php awscards_dropdown_terms( 'tcg_game', 'game', $selected_game ); ?>
                    </label>
                    <label><?php esc_html_e( 'Expansion', 'aws-cards-market' ); ?>
                        <?php awscards_dropdown_terms( 'tcg_set', 'set', $selected_set ); ?>
                    </label>
                    <label><?php esc_html_e( 'Rarity', 'aws-cards-market' ); ?>
                        <?php awscards_dropdown_terms( 'tcg_rarity', 'rarity', $selected_rarity ); ?>
                    </label>
                    <label><?php esc_html_e( 'Sort by', 'aws-cards-market' ); ?>
                        <select class="aws-select" name="sort">
                            <option value=""><?php esc_html_e( 'Newest', 'aws-cards-market' ); ?></option>
                            <option value="price_asc" <?php selected( $selected_sort, 'price_asc' ); ?>><?php esc_html_e( 'Lowest price', 'aws-cards-market' ); ?></option>
                            <option value="price_desc" <?php selected( $selected_sort, 'price_desc' ); ?>><?php esc_html_e( 'Highest price', 'aws-cards-market' ); ?></option>
                            <option value="offers_desc" <?php selected( $selected_sort, 'offers_desc' ); ?>><?php esc_html_e( 'Most offers', 'aws-cards-market' ); ?></option>
                            <option value="name_asc" <?php selected( $selected_sort, 'name_asc' ); ?>><?php esc_html_e( 'Name A-Z', 'aws-cards-market' ); ?></option>
                        </select>
                    </label>
                    <button class="aws-button" type="submit"><?php esc_html_e( 'Apply filters', 'aws-cards-market' ); ?></button>
                    <a class="aws-button secondary" href="<?php echo esc_url( awscards_archive_url() ); ?>"><?php esc_html_e( 'Reset', 'aws-cards-market' ); ?></a>
                </form>
            </aside>

            <div>
                <div class="aws-results-toolbar">
                    <strong><?php printf( esc_html__( '%s results', 'aws-cards-market' ), esc_html( $wp_query->found_posts ) ); ?></strong>
                    <span><?php esc_html_e( 'Grid view demo', 'aws-cards-market' ); ?></span>
                </div>

                <?php if ( have_posts() ) : ?>
                    <div class="aws-card-grid">
                        <?php
                        while ( have_posts() ) :
                            the_post();
                            get_template_part( 'template-parts/card', 'tile' );
                        endwhile;
                        ?>
                    </div>
                    <nav class="aws-pagination" aria-label="<?php esc_attr_e( 'Catalog pagination', 'aws-cards-market' ); ?>">
                        <?php the_posts_pagination( array( 'mid_size' => 1, 'prev_text' => '‹', 'next_text' => '›' ) ); ?>
                    </nav>
                <?php else : ?>
                    <div class="aws-empty"><?php esc_html_e( 'No cards matched your filters.', 'aws-cards-market' ); ?></div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>
<?php
get_footer();
