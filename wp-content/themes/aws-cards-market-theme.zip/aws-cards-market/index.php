<?php
/**
 * Fallback template.
 */
get_header();
?>
<section class="aws-section">
    <div class="aws-wrap">
        <?php if ( have_posts() ) : ?>
            <div class="aws-card-grid">
                <?php while ( have_posts() ) : the_post(); ?>
                    <article <?php post_class( 'aws-content-card' ); ?> style="padding:20px;">
                        <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                        <?php the_excerpt(); ?>
                    </article>
                <?php endwhile; ?>
            </div>
            <nav class="aws-pagination"><?php the_posts_pagination(); ?></nav>
        <?php else : ?>
            <div class="aws-empty"><?php esc_html_e( 'Nothing found.', 'aws-cards-market' ); ?></div>
        <?php endif; ?>
    </div>
</section>
<?php
get_footer();
