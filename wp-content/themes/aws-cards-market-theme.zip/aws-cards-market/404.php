<?php
get_header();
?>
<section class="aws-section">
    <div class="aws-wrap">
        <div class="aws-empty">
            <h1><?php esc_html_e( 'Page not found', 'aws-cards-market' ); ?></h1>
            <p><?php esc_html_e( 'Try browsing the card catalog instead.', 'aws-cards-market' ); ?></p>
            <a class="aws-button" href="<?php echo esc_url( awscards_archive_url() ); ?>"><?php esc_html_e( 'Browse cards', 'aws-cards-market' ); ?></a>
        </div>
    </div>
</section>
<?php
get_footer();
