<?php
/**
 * Single card template.
 */
get_header();
while ( have_posts() ) :
    the_post();
    $meta   = awscards_get_meta();
    $game   = awscards_primary_term( 'tcg_game' );
    $set    = awscards_primary_term( 'tcg_set' );
    $rarity = awscards_primary_term( 'tcg_rarity' );
    $offers = array(
        array( 'seller' => $meta['seller'], 'condition' => $meta['condition'], 'language' => $meta['language'], 'location' => $meta['location'], 'stock' => $meta['stock'], 'price' => $meta['min_price'] ),
        array( 'seller' => 'TopDeckStore', 'condition' => 'Excellent', 'language' => 'English', 'location' => 'Netherlands', 'stock' => '2', 'price' => (string) ( (float) $meta['min_price'] + 0.35 ) ),
        array( 'seller' => 'BinderVault', 'condition' => 'Light Played', 'language' => 'German', 'location' => 'Germany', 'stock' => '6', 'price' => (string) max( 0.01, (float) $meta['min_price'] - 0.08 ) ),
    );
    ?>
    <section class="aws-section">
        <div class="aws-wrap aws-single-grid">
            <aside class="aws-card-poster">
                <div class="aws-card-art">
                    <?php if ( has_post_thumbnail() ) : ?>
                        <?php the_post_thumbnail( 'large' ); ?>
                    <?php else : ?>
                        <span><?php echo esc_html( $game ? $game : __( 'Card', 'aws-cards-market' ) ); ?></span>
                    <?php endif; ?>
                </div>
            </aside>

            <div>
                <div class="aws-offer-panel">
                    <div class="aws-panel-heading">
                        <div>
                            <h1 class="aws-page-title"><?php the_title(); ?></h1>
                            <div class="aws-card-meta" style="margin-top:10px;">
                                <?php if ( $game ) : ?><span class="aws-tag"><?php echo esc_html( $game ); ?></span><?php endif; ?>
                                <?php if ( $set ) : ?><span class="aws-tag"><?php echo esc_html( $set ); ?></span><?php endif; ?>
                                <?php if ( $rarity ) : ?><span class="aws-tag"><?php echo esc_html( $rarity ); ?></span><?php endif; ?>
                            </div>
                        </div>
                        <div>
                            <small><?php esc_html_e( 'From', 'aws-cards-market' ); ?></small><br>
                            <span class="aws-price"><?php echo esc_html( awscards_format_price( $meta['min_price'] ) ); ?></span>
                        </div>
                    </div>
                    <table class="aws-list-table">
                        <thead>
                            <tr>
                                <th><?php esc_html_e( 'Seller', 'aws-cards-market' ); ?></th>
                                <th><?php esc_html_e( 'Condition', 'aws-cards-market' ); ?></th>
                                <th><?php esc_html_e( 'Language', 'aws-cards-market' ); ?></th>
                                <th><?php esc_html_e( 'Ships from', 'aws-cards-market' ); ?></th>
                                <th><?php esc_html_e( 'Stock', 'aws-cards-market' ); ?></th>
                                <th><?php esc_html_e( 'Price', 'aws-cards-market' ); ?></th>
                                <th><?php esc_html_e( 'Action', 'aws-cards-market' ); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ( $offers as $offer ) : ?>
                                <tr>
                                    <td><strong><?php echo esc_html( $offer['seller'] ); ?></strong></td>
                                    <td><?php echo esc_html( $offer['condition'] ); ?></td>
                                    <td><?php echo esc_html( $offer['language'] ); ?></td>
                                    <td><?php echo esc_html( $offer['location'] ); ?></td>
                                    <td><?php echo esc_html( $offer['stock'] ); ?></td>
                                    <td><strong><?php echo esc_html( awscards_format_price( $offer['price'] ) ); ?></strong></td>
                                    <td>
                                        <button class="aws-button small" type="button" data-aws-cart-add data-title="<?php echo esc_attr( get_the_title() . ' - ' . $offer['seller'] ); ?>" data-url="<?php the_permalink(); ?>" data-price="<?php echo esc_attr( $offer['price'] ); ?>"><?php esc_html_e( 'Add', 'aws-cards-market' ); ?></button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <div class="aws-description-panel">
                    <div class="aws-panel-heading">
                        <h2><?php esc_html_e( 'Card information', 'aws-cards-market' ); ?></h2>
                        <button class="aws-button small secondary" type="button" data-aws-wants-add data-title="<?php echo esc_attr( get_the_title() ); ?>" data-url="<?php the_permalink(); ?>" data-price="<?php echo esc_attr( $meta['min_price'] ); ?>"><?php esc_html_e( 'Add to wants', 'aws-cards-market' ); ?></button>
                    </div>
                    <div class="entry-content">
                        <?php the_content(); ?>
                        <p><strong><?php esc_html_e( 'Market price:', 'aws-cards-market' ); ?></strong> <?php echo esc_html( awscards_format_price( $meta['market_price'] ) ); ?></p>
                        <p><strong><?php esc_html_e( 'Total offers:', 'aws-cards-market' ); ?></strong> <?php echo esc_html( $meta['offer_count'] ); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php
endwhile;
get_footer();
