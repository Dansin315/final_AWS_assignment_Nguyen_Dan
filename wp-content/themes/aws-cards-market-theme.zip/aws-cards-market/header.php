<?php
/**
 * Theme header.
 */
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<header class="aws-site-header">
    <div class="aws-topbar">
        <div class="aws-wrap">
            <span><?php esc_html_e( 'Trading card marketplace demo for AWS WordPress HA', 'aws-cards-market' ); ?></span>
            <span><?php esc_html_e( 'Catalog • Seller offers • Wants list • Demo cart', 'aws-cards-market' ); ?></span>
        </div>
    </div>
    <div class="aws-mainbar">
        <div class="aws-wrap">
            <a class="aws-branding" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="<?php esc_attr_e( 'Home', 'aws-cards-market' ); ?>">
                <span class="aws-logo-mark">AC</span>
                <span><?php bloginfo( 'name' ); ?></span>
            </a>

            <nav class="aws-main-nav" aria-label="<?php esc_attr_e( 'Primary menu', 'aws-cards-market' ); ?>">
                <a href="<?php echo esc_url( awscards_archive_url() ); ?>"><?php esc_html_e( 'Cards', 'aws-cards-market' ); ?></a>
                <a href="<?php echo esc_url( home_url( '/wants-list/' ) ); ?>"><?php esc_html_e( 'Wants', 'aws-cards-market' ); ?></a>
                <?php
                wp_nav_menu(
                    array(
                        'theme_location' => 'primary',
                        'container'      => false,
                        'items_wrap'     => '%3$s',
                        'fallback_cb'    => false,
                        'depth'          => 1,
                    )
                );
                ?>
            </nav>

            <div class="aws-header-actions">
                <button type="button" class="aws-pill" data-aws-cart-toggle><?php esc_html_e( 'Cart', 'aws-cards-market' ); ?> <strong data-aws-cart-count>0</strong></button>
                <a class="aws-pill" href="<?php echo esc_url( home_url( '/wants-list/' ) ); ?>"><?php esc_html_e( 'Wants', 'aws-cards-market' ); ?> <strong data-aws-wants-count>0</strong></a>
            </div>
        </div>
    </div>
</header>
<div class="aws-mini-cart" data-aws-mini-cart aria-live="polite"></div>
<main id="primary" class="aws-site-main">
