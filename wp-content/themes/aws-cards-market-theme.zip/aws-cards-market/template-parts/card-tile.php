<?php
/**
 * Card tile partial.
 */
$meta  = awscards_get_meta();
$game  = awscards_primary_term( 'tcg_game' );
$set   = awscards_primary_term( 'tcg_set' );
$rarity = awscards_primary_term( 'tcg_rarity' );
?>
<article <?php post_class( 'aws-market-card' ); ?>>
    <a class="aws-card-art" href="<?php the_permalink(); ?>">
        <?php if ( has_post_thumbnail() ) : ?>
            <?php the_post_thumbnail( 'medium_large' ); ?>
        <?php else : ?>
            <span><?php echo esc_html( $game ? $game : __( 'Card', 'aws-cards-market' ) ); ?></span>
        <?php endif; ?>
    </a>
    <div class="aws-card-body">
        <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
        <div class="aws-card-meta">
            <?php if ( $game ) : ?><span class="aws-tag"><?php echo esc_html( $game ); ?></span><?php endif; ?>
            <?php if ( $set ) : ?><span class="aws-tag"><?php echo esc_html( $set ); ?></span><?php endif; ?>
            <?php if ( $rarity ) : ?><span class="aws-tag"><?php echo esc_html( $rarity ); ?></span><?php endif; ?>
        </div>
        <p><?php echo esc_html( get_the_excerpt() ); ?></p>
        <div class="aws-price-row">
            <span><small><?php esc_html_e( 'From', 'aws-cards-market' ); ?></small> <span class="aws-price"><?php echo esc_html( awscards_format_price( $meta['min_price'] ) ); ?></span></span>
            <span><?php printf( esc_html__( '%s offers', 'aws-cards-market' ), esc_html( $meta['offer_count'] ) ); ?></span>
        </div>
        <div class="aws-price-row">
            <a class="aws-button small secondary" href="<?php the_permalink(); ?>"><?php esc_html_e( 'View offers', 'aws-cards-market' ); ?></a>
            <button class="aws-button small" type="button" data-aws-wants-add data-title="<?php echo esc_attr( get_the_title() ); ?>" data-url="<?php the_permalink(); ?>" data-price="<?php echo esc_attr( $meta['min_price'] ); ?>"><?php esc_html_e( 'Want', 'aws-cards-market' ); ?></button>
        </div>
    </div>
</article>
