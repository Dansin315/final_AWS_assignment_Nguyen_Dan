<?php
/**
 * AWS Cards Market theme functions.
 *
 * This theme intentionally keeps the marketplace logic lightweight for a class
 * project. It is not a payment or escrow system. Cart and wants list actions are
 * demo features stored in the visitor's browser.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function awscards_setup() {
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );

    register_nav_menus(
        array(
            'primary' => __( 'Primary Menu', 'aws-cards-market' ),
            'footer'  => __( 'Footer Menu', 'aws-cards-market' ),
        )
    );
}
add_action( 'after_setup_theme', 'awscards_setup' );

function awscards_enqueue_assets() {
    wp_enqueue_style( 'aws-cards-market-style', get_stylesheet_uri(), array(), '1.1.0' );
    wp_enqueue_script( 'aws-cards-market-js', get_template_directory_uri() . '/assets/js/market.js', array(), '1.1.0', true );

    wp_localize_script(
        'aws-cards-market-js',
        'awsCardsMarket',
        array(
            'cartLabel'   => __( 'Demo Cart', 'aws-cards-market' ),
            'emptyCart'   => __( 'Your demo cart is empty.', 'aws-cards-market' ),
            'wantsLabel'  => __( 'Wants List', 'aws-cards-market' ),
            'emptyWants'  => __( 'Your wants list is empty.', 'aws-cards-market' ),
            'removeLabel' => __( 'Remove', 'aws-cards-market' ),
        )
    );
}
add_action( 'wp_enqueue_scripts', 'awscards_enqueue_assets' );

function awscards_register_content_types() {
    $labels = array(
        'name'               => __( 'Cards', 'aws-cards-market' ),
        'singular_name'      => __( 'Card', 'aws-cards-market' ),
        'menu_name'          => __( 'Cards', 'aws-cards-market' ),
        'add_new_item'       => __( 'Add New Card', 'aws-cards-market' ),
        'edit_item'          => __( 'Edit Card', 'aws-cards-market' ),
        'new_item'           => __( 'New Card', 'aws-cards-market' ),
        'view_item'          => __( 'View Card', 'aws-cards-market' ),
        'search_items'       => __( 'Search Cards', 'aws-cards-market' ),
        'not_found'          => __( 'No cards found', 'aws-cards-market' ),
        'not_found_in_trash' => __( 'No cards found in trash', 'aws-cards-market' ),
    );

    register_post_type(
        'tcg_card',
        array(
            'labels'       => $labels,
            'public'       => true,
            'has_archive'  => 'cards',
            'rewrite'      => array( 'slug' => 'cards' ),
            'menu_icon'    => 'dashicons-tickets-alt',
            'supports'     => array( 'title', 'editor', 'excerpt', 'thumbnail' ),
            'show_in_rest' => true,
        )
    );

    $taxonomies = array(
        'tcg_game'   => array( 'singular' => 'Game', 'plural' => 'Games', 'slug' => 'game' ),
        'tcg_set'    => array( 'singular' => 'Expansion', 'plural' => 'Expansions', 'slug' => 'expansion' ),
        'tcg_rarity' => array( 'singular' => 'Rarity', 'plural' => 'Rarities', 'slug' => 'rarity' ),
    );

    foreach ( $taxonomies as $taxonomy => $data ) {
        register_taxonomy(
            $taxonomy,
            'tcg_card',
            array(
                'labels'       => array(
                    'name'          => $data['plural'],
                    'singular_name' => $data['singular'],
                    'search_items'  => 'Search ' . $data['plural'],
                    'all_items'     => 'All ' . $data['plural'],
                    'edit_item'     => 'Edit ' . $data['singular'],
                    'add_new_item'  => 'Add New ' . $data['singular'],
                    'menu_name'     => $data['plural'],
                ),
                'hierarchical' => true,
                'rewrite'      => array( 'slug' => $data['slug'] ),
                'show_in_rest' => true,
                'show_admin_column' => true,
            )
        );
    }
}
add_action( 'init', 'awscards_register_content_types' );

function awscards_register_meta_boxes() {
    add_meta_box(
        'awscards_card_details',
        __( 'Marketplace Details', 'aws-cards-market' ),
        'awscards_render_card_details_meta_box',
        'tcg_card',
        'normal',
        'high'
    );
}
add_action( 'add_meta_boxes', 'awscards_register_meta_boxes' );

function awscards_meta_fields() {
    return array(
        '_awscards_min_price'    => array( 'label' => __( 'Starting price', 'aws-cards-market' ), 'type' => 'number', 'step' => '0.01', 'placeholder' => '0.49' ),
        '_awscards_market_price' => array( 'label' => __( 'Market price', 'aws-cards-market' ), 'type' => 'number', 'step' => '0.01', 'placeholder' => '0.65' ),
        '_awscards_offer_count'  => array( 'label' => __( 'Offer count', 'aws-cards-market' ), 'type' => 'number', 'step' => '1', 'placeholder' => '14' ),
        '_awscards_seller'       => array( 'label' => __( 'Example seller', 'aws-cards-market' ), 'type' => 'text', 'step' => '', 'placeholder' => 'CloudCardsEU' ),
        '_awscards_condition'    => array( 'label' => __( 'Condition', 'aws-cards-market' ), 'type' => 'text', 'step' => '', 'placeholder' => 'Near Mint' ),
        '_awscards_language'     => array( 'label' => __( 'Language', 'aws-cards-market' ), 'type' => 'text', 'step' => '', 'placeholder' => 'English' ),
        '_awscards_location'     => array( 'label' => __( 'Ships from', 'aws-cards-market' ), 'type' => 'text', 'step' => '', 'placeholder' => 'Germany' ),
        '_awscards_stock'        => array( 'label' => __( 'Stock', 'aws-cards-market' ), 'type' => 'number', 'step' => '1', 'placeholder' => '8' ),
    );
}

function awscards_render_card_details_meta_box( $post ) {
    wp_nonce_field( 'awscards_save_card_details', 'awscards_card_details_nonce' );
    echo '<div style="display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px;">';
    foreach ( awscards_meta_fields() as $key => $field ) {
        $value = get_post_meta( $post->ID, $key, true );
        printf(
            '<label><strong>%1$s</strong><br><input style="width:100%%" type="%2$s" step="%3$s" name="%4$s" value="%5$s" placeholder="%6$s"></label>',
            esc_html( $field['label'] ),
            esc_attr( $field['type'] ),
            esc_attr( $field['step'] ),
            esc_attr( $key ),
            esc_attr( $value ),
            esc_attr( $field['placeholder'] )
        );
    }
    echo '</div>';
}

function awscards_save_card_details( $post_id ) {
    if ( ! isset( $_POST['awscards_card_details_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['awscards_card_details_nonce'] ) ), 'awscards_save_card_details' ) ) {
        return;
    }

    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return;
    }

    if ( ! current_user_can( 'edit_post', $post_id ) ) {
        return;
    }

    foreach ( awscards_meta_fields() as $key => $field ) {
        if ( ! isset( $_POST[ $key ] ) ) {
            continue;
        }

        $raw = wp_unslash( $_POST[ $key ] );
        if ( 'number' === $field['type'] ) {
            $value = is_numeric( $raw ) ? (string) $raw : '';
        } else {
            $value = sanitize_text_field( $raw );
        }

        update_post_meta( $post_id, $key, $value );
    }
}
add_action( 'save_post_tcg_card', 'awscards_save_card_details' );

function awscards_get_meta( $post_id = null ) {
    $post_id = $post_id ? $post_id : get_the_ID();
    return array(
        'min_price'    => get_post_meta( $post_id, '_awscards_min_price', true ) ?: '0.00',
        'market_price' => get_post_meta( $post_id, '_awscards_market_price', true ) ?: '0.00',
        'offer_count'  => get_post_meta( $post_id, '_awscards_offer_count', true ) ?: '0',
        'seller'       => get_post_meta( $post_id, '_awscards_seller', true ) ?: 'DemoSeller',
        'condition'    => get_post_meta( $post_id, '_awscards_condition', true ) ?: 'Near Mint',
        'language'     => get_post_meta( $post_id, '_awscards_language', true ) ?: 'English',
        'location'     => get_post_meta( $post_id, '_awscards_location', true ) ?: 'EU',
        'stock'        => get_post_meta( $post_id, '_awscards_stock', true ) ?: '1',
    );
}

function awscards_format_price( $value ) {
    return '€' . number_format_i18n( (float) $value, 2 );
}

function awscards_primary_term( $taxonomy, $post_id = null ) {
    $terms = get_the_terms( $post_id ? $post_id : get_the_ID(), $taxonomy );
    if ( is_wp_error( $terms ) || empty( $terms ) ) {
        return '';
    }
    return $terms[0]->name;
}

function awscards_filter_archive_query( $query ) {
    if ( is_admin() || ! $query->is_main_query() ) {
        return;
    }

    if ( ! $query->is_post_type_archive( 'tcg_card' ) && ! $query->is_tax( array( 'tcg_game', 'tcg_set', 'tcg_rarity' ) ) ) {
        return;
    }

    if ( ! empty( $_GET['card_search'] ) ) {
        $query->set( 's', sanitize_text_field( wp_unslash( $_GET['card_search'] ) ) );
    }

    $tax_query = array();
    $filter_map = array(
        'game'   => 'tcg_game',
        'set'    => 'tcg_set',
        'rarity' => 'tcg_rarity',
    );

    foreach ( $filter_map as $param => $taxonomy ) {
        if ( empty( $_GET[ $param ] ) ) {
            continue;
        }
        $tax_query[] = array(
            'taxonomy' => $taxonomy,
            'field'    => 'slug',
            'terms'    => sanitize_title( wp_unslash( $_GET[ $param ] ) ),
        );
    }

    if ( $tax_query ) {
        $query->set( 'tax_query', $tax_query );
    }

    $sort = isset( $_GET['sort'] ) ? sanitize_key( wp_unslash( $_GET['sort'] ) ) : '';
    if ( 'price_desc' === $sort || 'price_asc' === $sort ) {
        $query->set( 'meta_key', '_awscards_min_price' );
        $query->set( 'orderby', 'meta_value_num' );
        $query->set( 'order', 'price_desc' === $sort ? 'DESC' : 'ASC' );
    } elseif ( 'offers_desc' === $sort ) {
        $query->set( 'meta_key', '_awscards_offer_count' );
        $query->set( 'orderby', 'meta_value_num' );
        $query->set( 'order', 'DESC' );
    } elseif ( 'name_asc' === $sort ) {
        $query->set( 'orderby', 'title' );
        $query->set( 'order', 'ASC' );
    }

    $query->set( 'posts_per_page', 12 );
}
add_action( 'pre_get_posts', 'awscards_filter_archive_query' );

function awscards_dropdown_terms( $taxonomy, $name, $selected = '' ) {
    $terms = get_terms(
        array(
            'taxonomy'   => $taxonomy,
            'hide_empty' => false,
        )
    );

    if ( is_wp_error( $terms ) ) {
        return;
    }

    echo '<select class="aws-select" name="' . esc_attr( $name ) . '">';
    echo '<option value="">' . esc_html__( 'Any', 'aws-cards-market' ) . '</option>';
    foreach ( $terms as $term ) {
        printf(
            '<option value="%1$s" %2$s>%3$s</option>',
            esc_attr( $term->slug ),
            selected( $selected, $term->slug, false ),
            esc_html( $term->name )
        );
    }
    echo '</select>';
}

function awscards_archive_url() {
    $url = get_post_type_archive_link( 'tcg_card' );
    return $url ? $url : home_url( '/' );
}

function awscards_catalog_shortcode() {
    ob_start();
    $cards = new WP_Query(
        array(
            'post_type'      => 'tcg_card',
            'posts_per_page' => 8,
            'orderby'        => 'date',
            'order'          => 'DESC',
        )
    );
    if ( $cards->have_posts() ) {
        echo '<div class="aws-card-grid">';
        while ( $cards->have_posts() ) {
            $cards->the_post();
            get_template_part( 'template-parts/card', 'tile' );
        }
        echo '</div>';
        wp_reset_postdata();
    } else {
        echo '<div class="aws-empty">' . esc_html__( 'No cards yet. Add cards in WordPress Admin > Cards.', 'aws-cards-market' ) . '</div>';
    }
    return ob_get_clean();
}
add_shortcode( 'awscards_catalog', 'awscards_catalog_shortcode' );

function awscards_wants_shortcode() {
    ob_start();
    ?>
    <div class="aws-content-card" style="padding:20px;">
        <h2><?php esc_html_e( 'My Wants List', 'aws-cards-market' ); ?></h2>
        <p><?php esc_html_e( 'This demo wants list is stored in the browser using localStorage.', 'aws-cards-market' ); ?></p>
        <div data-aws-wants-list></div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode( 'awscards_wants', 'awscards_wants_shortcode' );

function awscards_add_admin_page() {
    add_theme_page(
        __( 'AWS Cards Demo Data', 'aws-cards-market' ),
        __( 'AWS Cards Demo', 'aws-cards-market' ),
        'manage_options',
        'aws-cards-demo',
        'awscards_render_admin_page'
    );
}
add_action( 'admin_menu', 'awscards_add_admin_page' );

function awscards_render_admin_page() {
    if ( isset( $_POST['awscards_seed_demo'] ) && check_admin_referer( 'awscards_seed_demo_action', 'awscards_seed_demo_nonce' ) ) {
        awscards_seed_demo_cards();
        echo '<div class="notice notice-success"><p>' . esc_html__( 'Demo cards created or updated.', 'aws-cards-market' ) . '</p></div>';
    }
    ?>
    <div class="wrap">
        <h1><?php esc_html_e( 'AWS Cards Demo Data', 'aws-cards-market' ); ?></h1>
        <p><?php esc_html_e( 'Create a small demo catalog with games, expansions, prices, sellers, and offer counts.', 'aws-cards-market' ); ?></p>
        <form method="post">
            <?php wp_nonce_field( 'awscards_seed_demo_action', 'awscards_seed_demo_nonce' ); ?>
            <p><button class="button button-primary" type="submit" name="awscards_seed_demo" value="1"><?php esc_html_e( 'Create Demo Cards', 'aws-cards-market' ); ?></button></p>
        </form>
        <p><?php esc_html_e( 'After seeding, visit the Cards archive from the front end.', 'aws-cards-market' ); ?></p>
    </div>
    <?php
}

function awscards_seed_demo_cards() {
    $demo_cards = array(
        array( 'title' => 'Cloud Dragon', 'game' => 'Magic Style', 'set' => 'AWS Core Set', 'rarity' => 'Mythic', 'price' => '4.99', 'market' => '5.80', 'offers' => '18', 'seller' => 'CloudCardsEU', 'condition' => 'Near Mint', 'language' => 'English', 'location' => 'Germany', 'stock' => '7' ),
        array( 'title' => 'Elastic Warrior', 'game' => 'Magic Style', 'set' => 'AWS Core Set', 'rarity' => 'Rare', 'price' => '1.25', 'market' => '1.40', 'offers' => '32', 'seller' => 'ScaleMaster', 'condition' => 'Excellent', 'language' => 'English', 'location' => 'France', 'stock' => '12' ),
        array( 'title' => 'RDS Oracle', 'game' => 'Monster Cards', 'set' => 'Database Dawn', 'rarity' => 'Ultra Rare', 'price' => '7.50', 'market' => '8.20', 'offers' => '11', 'seller' => 'RelationalTCG', 'condition' => 'Near Mint', 'language' => 'German', 'location' => 'Germany', 'stock' => '3' ),
        array( 'title' => 'S3 Archive Keeper', 'game' => 'Monster Cards', 'set' => 'Storage Saga', 'rarity' => 'Common', 'price' => '0.08', 'market' => '0.12', 'offers' => '120', 'seller' => 'BucketShop', 'condition' => 'Light Played', 'language' => 'English', 'location' => 'Spain', 'stock' => '48' ),
        array( 'title' => 'Auto Scaling Angel', 'game' => 'Pocket Creatures', 'set' => 'High Availability', 'rarity' => 'Holo', 'price' => '2.10', 'market' => '2.45', 'offers' => '24', 'seller' => 'HACollector', 'condition' => 'Near Mint', 'language' => 'Italian', 'location' => 'Italy', 'stock' => '5' ),
        array( 'title' => 'Load Balancer Beast', 'game' => 'Pocket Creatures', 'set' => 'High Availability', 'rarity' => 'Rare', 'price' => '0.95', 'market' => '1.05', 'offers' => '44', 'seller' => 'StickySessions', 'condition' => 'Excellent', 'language' => 'English', 'location' => 'Netherlands', 'stock' => '17' ),
    );

    foreach ( $demo_cards as $card ) {
        $existing = get_page_by_title( $card['title'], OBJECT, 'tcg_card' );
        $post_id = $existing ? $existing->ID : 0;
        $post_data = array(
            'ID'           => $post_id,
            'post_title'   => $card['title'],
            'post_type'    => 'tcg_card',
            'post_status'  => 'publish',
            'post_content' => 'Demo card description for the AWS Cards Market class project. Replace this with real card text, rules notes, grading notes, or product details.',
            'post_excerpt' => 'Demo marketplace listing with seller offers and price metadata.',
        );
        $post_id = $post_id ? wp_update_post( $post_data ) : wp_insert_post( $post_data );

        if ( is_wp_error( $post_id ) || ! $post_id ) {
            continue;
        }

        wp_set_object_terms( $post_id, $card['game'], 'tcg_game' );
        wp_set_object_terms( $post_id, $card['set'], 'tcg_set' );
        wp_set_object_terms( $post_id, $card['rarity'], 'tcg_rarity' );

        update_post_meta( $post_id, '_awscards_min_price', $card['price'] );
        update_post_meta( $post_id, '_awscards_market_price', $card['market'] );
        update_post_meta( $post_id, '_awscards_offer_count', $card['offers'] );
        update_post_meta( $post_id, '_awscards_seller', $card['seller'] );
        update_post_meta( $post_id, '_awscards_condition', $card['condition'] );
        update_post_meta( $post_id, '_awscards_language', $card['language'] );
        update_post_meta( $post_id, '_awscards_location', $card['location'] );
        update_post_meta( $post_id, '_awscards_stock', $card['stock'] );
    }
}

function awscards_create_wants_page() {
    $existing = get_page_by_path( 'wants-list' );
    if ( ! $existing ) {
        wp_insert_post(
            array(
                'post_title'   => 'Wants List',
                'post_name'    => 'wants-list',
                'post_type'    => 'page',
                'post_status'  => 'publish',
                'post_content' => '[awscards_wants]',
            )
        );
    }
    flush_rewrite_rules();
}
add_action( 'after_switch_theme', 'awscards_create_wants_page' );

function awscards_admin_notice() {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }
    $screen = get_current_screen();
    if ( ! $screen || 'themes' !== $screen->id ) {
        return;
    }
    echo '<div class="notice notice-info is-dismissible"><p>' . wp_kses_post( __( 'AWS Cards Market is active. Go to <strong>Appearance > AWS Cards Demo</strong> to create sample cards.', 'aws-cards-market' ) ) . '</p></div>';
}
add_action( 'admin_notices', 'awscards_admin_notice' );
