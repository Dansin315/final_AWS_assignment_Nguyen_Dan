<?php
/**
 * Theme footer.
 */
?>
</main>
<footer class="aws-site-footer">
    <div class="aws-wrap aws-footer-grid">
        <div>
            <h2><?php bloginfo( 'name' ); ?></h2>
            <p><?php esc_html_e( 'A WordPress theme for demonstrating EC2, ALB, Auto Scaling, RDS, and web-service deployment concepts.', 'aws-cards-market' ); ?></p>
        </div>
        <div>
            <h3><?php esc_html_e( 'Demo Features', 'aws-cards-market' ); ?></h3>
            <p><?php esc_html_e( 'Catalog, filters, seller offers, wants list, and browser-side demo cart.', 'aws-cards-market' ); ?></p>
        </div>
        <div>
            <h3><?php esc_html_e( 'Project Note', 'aws-cards-market' ); ?></h3>
            <p><?php esc_html_e( 'For production ecommerce, add a real payment, order, and user-verification plugin. This theme is a class-project prototype.', 'aws-cards-market' ); ?></p>
        </div>
    </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
