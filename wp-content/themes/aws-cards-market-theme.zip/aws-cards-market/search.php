<?php
/**
 * Search results template.
 */
get_header();
?>
<section class="aws-section">
    <div class="aws-wrap">
        <div class="aws-section-heading">
            <div>
                <h1 class="aws-page-title"><?php printf( esc_html__( 'Search results for: %s', 'aws-cards-market' ), esc_html( get_search_query() ) ); ?></h1>
            </div>
        </div>
        <?php if ( have_posts() ) : ?>
            <div class="aws-card-grid">
                <?php while ( have_posts() ) : the_post(); ?>
                    <?php if ( 'tcg_card' === get_post_type() ) : ?>
                        <?php get_template_part( 'template-parts/card', 'tile' ); ?>
                    <?php else : ?>
                        <article <?php post_class( 'aws-content-card' ); ?> style="padding:20px;">
                            <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                            <?php the_excerpt(); ?>
                        </article>
                    <?php endif; ?>
                <?php endwhile; ?>
            </div>
            <nav class="aws-pagination"><?php the_posts_pagination(); ?></nav>
        <?php else : ?>
            <div class="aws-empty"><?php esc_html_e( 'No results found.', 'aws-cards-market' ); ?></div>
        <?php endif; ?>
    </div>
</section>
<?php
get_footer();
