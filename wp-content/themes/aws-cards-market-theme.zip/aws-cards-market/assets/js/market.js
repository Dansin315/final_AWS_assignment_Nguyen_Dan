(function () {
  'use strict';

  const cartKey = 'awsCardsMarketCart';
  const wantsKey = 'awsCardsMarketWants';

  function readItems(key) {
    try {
      const value = JSON.parse(window.localStorage.getItem(key) || '[]');
      return Array.isArray(value) ? value : [];
    } catch (error) {
      return [];
    }
  }

  function writeItems(key, items) {
    window.localStorage.setItem(key, JSON.stringify(items));
  }

  function money(value) {
    const number = Number(value || 0);
    return '€' + number.toFixed(2);
  }

  function updateCounts() {
    const cartItems = readItems(cartKey);
    const wantsItems = readItems(wantsKey);
    document.querySelectorAll('[data-aws-cart-count]').forEach((el) => { el.textContent = String(cartItems.length); });
    document.querySelectorAll('[data-aws-wants-count]').forEach((el) => { el.textContent = String(wantsItems.length); });
  }

  function addItem(key, data) {
    const items = readItems(key);
    items.push({
      id: Date.now() + '-' + Math.random().toString(16).slice(2),
      title: data.title || 'Card',
      url: data.url || window.location.href,
      price: data.price || '0.00'
    });
    writeItems(key, items);
    updateCounts();
    renderCart();
    renderWantsList();
  }

  function removeItem(key, id) {
    const items = readItems(key).filter((item) => item.id !== id);
    writeItems(key, items);
    updateCounts();
    renderCart();
    renderWantsList();
  }

  function renderCart() {
    const panel = document.querySelector('[data-aws-mini-cart]');
    if (!panel) return;

    const items = readItems(cartKey);
    const label = window.awsCardsMarket ? window.awsCardsMarket.cartLabel : 'Demo Cart';
    const empty = window.awsCardsMarket ? window.awsCardsMarket.emptyCart : 'Your demo cart is empty.';
    const removeLabel = window.awsCardsMarket ? window.awsCardsMarket.removeLabel : 'Remove';

    if (!items.length) {
      panel.innerHTML = '<h2>' + label + '</h2><p>' + empty + '</p>';
      return;
    }

    const total = items.reduce((sum, item) => sum + Number(item.price || 0), 0);
    panel.innerHTML = '<h2>' + label + '</h2>' + items.map((item) => {
      return '<div class="aws-mini-cart-item"><div><strong><a href="' + item.url + '">' + item.title + '</a></strong><br><span>' + money(item.price) + '</span></div><button class="aws-button small secondary" type="button" data-aws-cart-remove="' + item.id + '">' + removeLabel + '</button></div>';
    }).join('') + '<p><strong>Total: ' + money(total) + '</strong></p><p><small>This is a front-end demo cart, not a real checkout.</small></p>';
  }

  function renderWantsList() {
    const targets = document.querySelectorAll('[data-aws-wants-list]');
    if (!targets.length) return;

    const items = readItems(wantsKey);
    const empty = window.awsCardsMarket ? window.awsCardsMarket.emptyWants : 'Your wants list is empty.';
    const removeLabel = window.awsCardsMarket ? window.awsCardsMarket.removeLabel : 'Remove';

    targets.forEach((target) => {
      if (!items.length) {
        target.innerHTML = '<div class="aws-empty">' + empty + '</div>';
        return;
      }
      target.innerHTML = '<table class="aws-list-table"><thead><tr><th>Card</th><th>Starting price</th><th>Action</th></tr></thead><tbody>' + items.map((item) => {
        return '<tr><td><a href="' + item.url + '">' + item.title + '</a></td><td>' + money(item.price) + '</td><td><button class="aws-button small secondary" type="button" data-aws-wants-remove="' + item.id + '">' + removeLabel + '</button></td></tr>';
      }).join('') + '</tbody></table>';
    });
  }

  document.addEventListener('click', function (event) {
    const cartAdd = event.target.closest('[data-aws-cart-add]');
    const wantsAdd = event.target.closest('[data-aws-wants-add]');
    const cartToggle = event.target.closest('[data-aws-cart-toggle]');
    const cartRemove = event.target.closest('[data-aws-cart-remove]');
    const wantsRemove = event.target.closest('[data-aws-wants-remove]');

    if (cartAdd) {
      addItem(cartKey, cartAdd.dataset);
      const panel = document.querySelector('[data-aws-mini-cart]');
      if (panel) panel.classList.add('is-open');
    }

    if (wantsAdd) {
      addItem(wantsKey, wantsAdd.dataset);
      wantsAdd.textContent = 'Added';
      window.setTimeout(function () { wantsAdd.textContent = 'Want'; }, 1200);
    }

    if (cartToggle) {
      const panel = document.querySelector('[data-aws-mini-cart]');
      if (panel) panel.classList.toggle('is-open');
    }

    if (cartRemove) {
      removeItem(cartKey, cartRemove.getAttribute('data-aws-cart-remove'));
    }

    if (wantsRemove) {
      removeItem(wantsKey, wantsRemove.getAttribute('data-aws-wants-remove'));
    }
  });

  document.addEventListener('DOMContentLoaded', function () {
    updateCounts();
    renderCart();
    renderWantsList();
  });
})();
