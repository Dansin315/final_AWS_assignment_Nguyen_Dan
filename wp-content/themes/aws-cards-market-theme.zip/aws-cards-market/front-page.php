<?php
/**
 * Front page template.
 */
get_header();
?>
<section class="aws-hero">
    <div class="aws-wrap aws-hero-grid">
        <div>
            <span class="aws-eyebrow"><?php esc_html_e( 'AWS Cards Marketplace', 'aws-cards-market' ); ?></span>
            <h1><?php esc_html_e( 'Buy and Sell Trading Card Games Online. Pick your game!', 'aws-cards-market' ); ?></h1>
            <p><?php esc_html_e( 'Cardmarket, the peer-to-peer online marketplace that allows Buying/Selling trading.', 'aws-cards-market' ); ?></p>
        </div>
        <div class="aws-trending-card">
            <h2><?php esc_html_e( 'Trending', 'aws-cards-market' ); ?></h2>
            <p><?php esc_html_e( 'Popular cards right now', 'aws-cards-market' ); ?></p>
            <?php
            $trending_cards = new WP_Query(
                array(
                    'post_type'      => 'tcg_card',
                    'posts_per_page' => 6,
                    'meta_key'       => '_awscards_offer_count',
                    'orderby'        => 'meta_value_num',
                    'order'          => 'DESC',
                )
            );
            if ( $trending_cards->have_posts() ) :
                ?>
                <ol class="aws-trending-list">
                    <?php
                    while ( $trending_cards->have_posts() ) :
                        $trending_cards->the_post();
                        $trending_meta = awscards_get_meta();
                        ?>
                        <li>
                            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                            <span><?php echo esc_html( awscards_format_price( $trending_meta['min_price'] ) ); ?> · <?php printf( esc_html__( '%s offers', 'aws-cards-market' ), esc_html( $trending_meta['offer_count'] ) ); ?></span>
                        </li>
                        <?php
                    endwhile;
                    wp_reset_postdata();
                    ?>
                </ol>
                <?php
            else :
                ?>
                <ul class="aws-trending-list aws-trending-placeholder">
                    <li><span><?php esc_html_e( 'Cloud Dragon', 'aws-cards-market' ); ?></span></li>
                    <li><span><?php esc_html_e( 'Elastic Warrior', 'aws-cards-market' ); ?></span></li>
                    <li><span><?php esc_html_e( 'RDS Oracle', 'aws-cards-market' ); ?></span></li>
                    <li><span><?php esc_html_e( 'S3 Archive Keeper', 'aws-cards-market' ); ?></span></li>
                </ul>
                <?php
            endif;
            ?>
        </div>
    </div>
</section>

<section class="aws-section">
    <div class="aws-wrap">
        <div class="aws-section-heading">
            <div>
                <h2><?php esc_html_e( 'Pick a game', 'aws-cards-market' ); ?></h2>
                <p><?php esc_html_e( 'Game tiles link into the same shared card catalog.', 'aws-cards-market' ); ?></p>
            </div>
            <a class="aws-button secondary" href="<?php echo esc_url( awscards_archive_url() ); ?>"><?php esc_html_e( 'Browse all cards', 'aws-cards-market' ); ?></a>
        </div>
        <div class="aws-game-grid">
            <?php
            $games = get_terms( array( 'taxonomy' => 'tcg_game', 'hide_empty' => false, 'number' => 4 ) );
            if ( ! is_wp_error( $games ) && $games ) :
                foreach ( $games as $game ) :
                    ?>
                    <a class="aws-game-card" href="<?php echo esc_url( add_query_arg( 'game', $game->slug, awscards_archive_url() ) ); ?>">
                        <span class="aws-game-icon"><?php echo esc_html( strtoupper( substr( $game->name, 0, 2 ) ) ); ?></span>
                        <h3><?php echo esc_html( $game->name ); ?></h3>
                        <span><?php printf( esc_html__( '%d listings', 'aws-cards-market' ), (int) $game->count ); ?></span>
                    </a>
                    <?php
                endforeach;
            else :
                for ( $i = 1; $i <= 4; $i++ ) :
                    ?>
                    <div class="aws-game-card">
                        <span class="aws-game-icon">TCG</span>
                        <h3><?php printf( esc_html__( 'Game %d', 'aws-cards-market' ), $i ); ?></h3>
                        <span><?php esc_html_e( 'Create demo data to activate this tile.', 'aws-cards-market' ); ?></span>
                    </div>
                    <?php
                endfor;
            endif;
            ?>
        </div>
    </div>
</section>

<section class="aws-section">
    <div class="aws-wrap">
        <div class="aws-section-heading">
            <div>
                <h2><?php esc_html_e( 'Latest card offers', 'aws-cards-market' ); ?></h2>
                <p><?php esc_html_e( 'A Cardmarket-style catalog layout without copying logos, brand assets, or protected design.', 'aws-cards-market' ); ?></p>
            </div>
        </div>
        <?php echo do_shortcode( '[awscards_catalog]' ); ?>
    </div>
</section>
<?php
get_footer();
