<?php
/**
 * Front page template.
 */
get_header();
?>
<section class="aws-hero">
    <div class="aws-wrap aws-hero-grid">
        <div>
            <span class="aws-eyebrow"><?php esc_html_e( 'AWS Cards Marketplace', 'aws-cards-market' ); ?></span>
            <h1><?php esc_html_e( 'Buy and sell demo trading cards on a highly available WordPress service.', 'aws-cards-market' ); ?></h1>
            <p><?php esc_html_e( 'A clean marketplace-style theme with card search, product listings, seller offers, wants list, and demo cart interactions.', 'aws-cards-market' ); ?></p>
            <div class="aws-search-panel">
                <form class="aws-search-form" method="get" action="<?php echo esc_url( awscards_archive_url() ); ?>">
                    <label class="screen-reader-text" for="front-card-search"><?php esc_html_e( 'Search cards', 'aws-cards-market' ); ?></label>
                    <input id="front-card-search" class="aws-input" type="search" name="card_search" placeholder="<?php esc_attr_e( 'Search for a card name...', 'aws-cards-market' ); ?>">
                    <?php awscards_dropdown_terms( 'tcg_game', 'game' ); ?>
                    <button class="aws-button" type="submit"><?php esc_html_e( 'Search', 'aws-cards-market' ); ?></button>
                </form>
            </div>
        </div>
        <div class="aws-stat-card">
            <div><strong><?php echo esc_html( wp_count_posts( 'tcg_card' )->publish ); ?></strong><?php esc_html_e( 'cards in the demo catalog', 'aws-cards-market' ); ?></div>
            <div><strong>2+</strong><?php esc_html_e( 'EC2 instances supported through ASG', 'aws-cards-market' ); ?></div>
            <div><strong>RDS</strong><?php esc_html_e( 'shared database for WordPress content', 'aws-cards-market' ); ?></div>
        </div>
    </div>
</section>

<section class="aws-section">
    <div class="aws-wrap">
        <div class="aws-section-heading">
            <div>
                <h2><?php esc_html_e( 'Pick a game', 'aws-cards-market' ); ?></h2>
                <p><?php esc_html_e( 'Game tiles link into the same shared card catalog.', 'aws-cards-market' ); ?></p>
            </div>
            <a class="aws-button secondary" href="<?php echo esc_url( awscards_archive_url() ); ?>"><?php esc_html_e( 'Browse all cards', 'aws-cards-market' ); ?></a>
        </div>
        <div class="aws-game-grid">
            <?php
            $games = get_terms( array( 'taxonomy' => 'tcg_game', 'hide_empty' => false, 'number' => 4 ) );
            if ( ! is_wp_error( $games ) && $games ) :
                foreach ( $games as $game ) :
                    ?>
                    <a class="aws-game-card" href="<?php echo esc_url( add_query_arg( 'game', $game->slug, awscards_archive_url() ) ); ?>">
                        <span class="aws-game-icon"><?php echo esc_html( strtoupper( substr( $game->name, 0, 2 ) ) ); ?></span>
                        <h3><?php echo esc_html( $game->name ); ?></h3>
                        <span><?php printf( esc_html__( '%d listings', 'aws-cards-market' ), (int) $game->count ); ?></span>
                    </a>
                    <?php
                endforeach;
            else :
                for ( $i = 1; $i <= 4; $i++ ) :
                    ?>
                    <div class="aws-game-card">
                        <span class="aws-game-icon">TCG</span>
                        <h3><?php printf( esc_html__( 'Game %d', 'aws-cards-market' ), $i ); ?></h3>
                        <span><?php esc_html_e( 'Create demo data to activate this tile.', 'aws-cards-market' ); ?></span>
                    </div>
                    <?php
                endfor;
            endif;
            ?>
        </div>
    </div>
</section>

<section class="aws-section">
    <div class="aws-wrap">
        <div class="aws-section-heading">
            <div>
                <h2><?php esc_html_e( 'Latest card offers', 'aws-cards-market' ); ?></h2>
                <p><?php esc_html_e( 'A Cardmarket-style catalog layout without copying logos, brand assets, or protected design.', 'aws-cards-market' ); ?></p>
            </div>
        </div>
        <?php echo do_shortcode( '[awscards_catalog]' ); ?>
    </div>
</section>
<?php
get_footer();
